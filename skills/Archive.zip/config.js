var config = {
    appid: "amzn1.ask.skill.1adf6cd4-a397-4d29-8769-fe008bc0aaf6",
    host : "alexa.artshee.com",
    port : "80"
};

module.exports = config;